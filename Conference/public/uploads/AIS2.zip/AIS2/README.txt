you should compile this program in JAVA 1.7.
use make to compile, and use “make run” to run the program
in the console, you need to give the type and domain, then it will give you the result.
Dumpfile is in dumpfile.txt