import java.net.InetAddress;
import java.net.UnknownHostException;

import org.xbill.DNS.Address;
import org.xbill.DNS.Lookup;
import org.xbill.DNS.Record;
import org.xbill.DNS.SRVRecord;
import org.xbill.DNS.TextParseException;
import org.xbill.DNS.Type;


public class DNSSolver {
	public static String[] queryA(String domain) throws UnknownHostException{
		return query(domain,Type.A);
	}
	public static String[] querySRV(String domain) throws UnknownHostException{
		return query(domain,Type.SRV);
	}
	public static String[] queryC(String domain) throws UnknownHostException{
		return query(domain,Type.CNAME);
	}
	private static String[] query(String domain,int type){
		String[] result = null;
		try {
			Record[] records = new Lookup(domain,type).run();
			result = new String[records.length];
			int i=0;
			for(Record record:records){
				result[i++]=record.toString();
			}
		} catch (TextParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
}
