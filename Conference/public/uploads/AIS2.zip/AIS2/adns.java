import java.net.UnknownHostException;
import java.util.Scanner;


public class adns {
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		while(true){
			System.out.print("adns ");
			String command = scanner.nextLine();
			if(command.split(" ").length==2){
				String[] cmd = command.split(" ");
				String domain = cmd[1];
				String type = cmd[0].toLowerCase();
				try{
					if(type.equals("a")){
						String[] r = DNSSolver.queryA(domain);
						for(int i=0;i<r.length;i++){
							System.out.println(r[i]);
						}
					}else if(type.equals("cname")){
						String[] r = DNSSolver.queryC(domain);
						for(int i=0;i<r.length;i++){
							System.out.println(r[i]);
						}
					}else if(type.equals("srv")){
						String[] r = DNSSolver.querySRV(domain);
						for(int i=0;i<r.length;i++){
							System.out.println(r[i]);
						}
					}else{
						System.out.println("not available type!");
					}
				}catch(Exception e){
					
				}
			}else{
				System.out.println("wrong command!");
			}
		}
	}
}
